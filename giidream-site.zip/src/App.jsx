import React from 'react'

export default function App() {
  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-r from-blue-600 to-indigo-800 text-white">
      <h1 className="text-4xl font-bold">GII DREAM — Холдинг</h1>
    </div>
  )
}