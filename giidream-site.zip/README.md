# 🌍 GII DREAM — Corporate Holding Website

Этот проект — официальный сайт холдинга **GII DREAM**.  
Технологии: React + Tailwind + i18n (RU/UZ/EN).

## 🚀 Онлайн запуск
Нажмите кнопку ниже, чтобы развернуть сайт на Vercel:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/gubaydulin1992-ux/giidream-site)

## 📦 Локальный запуск
```bash
npm install
npm run dev
```
Откройте http://localhost:5173

---
© 2025 GII DREAM
